﻿using Snmp.EventWorker.Services;
using SNMP.ENTITY.Events.Snmp;
using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Text;

namespace Snmp.EventWorker.Polling
{
    public class PollingManager : IPollingManager
    {
        private readonly ILogger<PollingManager> _logger;
        private readonly ConcurrentDictionary<int, CancellationTokenSource> _runningPollings = new();
        private readonly ISnmpService _snmpService;
        public PollingManager(ILogger<PollingManager> logger, ISnmpService snmpService)
        {
            _logger = logger;
            _snmpService = snmpService;
      
        }

        public bool IsRunning(int deviceId)
        {
            return _runningPollings.ContainsKey(deviceId);
        }

        public Task StartAsync(DevicePollingStartedEvent devicePollingStartedEvent, CancellationToken cancellationToken)
        {
            if (_runningPollings.ContainsKey(devicePollingStartedEvent.DeviceId))
            {
                _logger.LogWarning("Polling already running. DeviceId: {DeviceId}", devicePollingStartedEvent.DeviceId);

                return Task.CompletedTask;
            }

            var cts = CancellationTokenSource.CreateLinkedTokenSource(cancellationToken);

            if (!_runningPollings.TryAdd(devicePollingStartedEvent.DeviceId, cts))
            {
                _logger.LogWarning(
                    "Polling already running. DeviceId: {DeviceId}",
                    devicePollingStartedEvent.DeviceId);

                return Task.CompletedTask;
            }

            _ = Task.Run(async () =>
            {
                try
                {
                    while (!cts.Token.IsCancellationRequested)
                    {
                        var result = await _snmpService.GetAsync(devicePollingStartedEvent.IpAddress,devicePollingStartedEvent.Port,"1.3.6.1.2.1.1.3.0",cts.Token);

                        _logger.LogInformation(
                            "SNMP Result: {Result}",
                            result);
                        await Task.Delay(
                            TimeSpan.FromSeconds(devicePollingStartedEvent.IntervalSeconds),
                            cts.Token);
                    }
                }
                catch (OperationCanceledException)
                {
                    _logger.LogInformation(
                        "Polling cancelled. DeviceId: {DeviceId}",
                        devicePollingStartedEvent.DeviceId);
                }
                finally
                {
                    _runningPollings.TryRemove(devicePollingStartedEvent.DeviceId, out _);
                }

            }, cts.Token);

            _logger.LogInformation(
                "Polling started. DeviceId: {DeviceId}",
                devicePollingStartedEvent.DeviceId);

            return Task.CompletedTask;
        }

        public Task StopAsync(int deviceId)
        {
            if (_runningPollings.TryRemove(deviceId, out var cts))
            {
                cts.Cancel();
                cts.Dispose();

                _logger.LogInformation("Polling stopped. DeviceId: {DeviceId}", deviceId);
            }

            return Task.CompletedTask;
        }
    }
}
