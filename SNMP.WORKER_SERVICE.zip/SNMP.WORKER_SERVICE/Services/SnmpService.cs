﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Snmp.EventWorker.Services
{
    public class SnmpService : ISnmpService
    {
        public Task<string?> GetAsync(string ipAddress, int port, string oid, CancellationToken cancellationToken = default)
        {
            throw new NotImplementedException();
        }
    }
}
